const mongoose = require('mongoose');


// const dbUri = 'mongodb+srv://admin:admin123@cluster0.stdp4zq.mongodb.net/Childvocabulary?retryWrites=true&w=majority'
// const dbUri = 'mongodb://localhost:27017/Sample_ChildVocability'


module.exports = () =>{
    return mongoose.connect(dbUri)
}